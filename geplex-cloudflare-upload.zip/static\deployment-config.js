﻿window.GEPLEX_DEPLOYMENT = {
  apiBase: "",
  firebaseConfig: {"apiKey":"AIzaSyCvefrQ-bJZ_mr97j_aLiYptlfKYb3blAs","authDomain":"geplex-ai.firebaseapp.com","databaseURL":"https://geplex-ai-default-rtdb.firebaseio.com","projectId":"geplex-ai","storageBucket":"geplex-ai.firebasestorage.app","messagingSenderId":"587292925892","appId":"1:587292925892:web:1450a207788d49a379ce91","measurementId":"G-R0EX7E2VYG"}
};
